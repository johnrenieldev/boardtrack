<?php
/**
 * BoardTrack — Register Page
 * app/views/auth/register.php
 * Layout: main.php
 */
$errors  = $_SESSION['flash'] ?? [];
unset($_SESSION['flash']);
$old     = $_SESSION['form_old'] ?? [];
unset($_SESSION['form_old']);
?>
<div class="min-h-screen flex">

  <!-- Left panel -->
  <div class="hidden lg:flex flex-col justify-between w-80 bg-gray-900 p-10 fixed h-screen left-0 top-0">
    <div>
      <div class="font-heading font-bold text-2xl text-white mb-1">Board<span class="text-brand-500">Track</span></div>
      <div class="text-gray-400 text-sm">Boarding House Management</div>
    </div>
    <div>
      <h2 class="text-white font-bold text-xl leading-snug mb-4">Registration Steps</h2>
      <?php
        $steps = ['Fill in your details','Add guardian/emergency contact','Upload government ID','Complete personality quiz','Wait for landlord approval'];
        foreach ($steps as $i => $s):
      ?>
      <div class="flex items-start gap-3 mb-3">
        <div class="w-5 h-5 rounded-full bg-brand-600 text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5"><?= $i+1 ?></div>
        <span class="text-gray-300 text-sm"><?= $s ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Form panel -->
  <div class="flex-1 flex items-start justify-center p-6 bg-gray-50 overflow-y-auto py-10 lg:ml-80">
    <div class="w-full max-w-md">

      <a href="<?= Router::url('home/index') ?>" class="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700 mb-6">
        <i class="fa-solid fa-arrow-left text-xs"></i> Back
      </a>

      <h1 class="font-heading font-bold text-2xl text-gray-900 mb-1">Create tenant account</h1>
      <p class="text-gray-500 text-sm mb-6">For new boarding house applicants only.</p>

      <?php if (!empty($errors)): ?>
        <?php foreach ($errors as $f): ?>
          <?php if (empty($f['field'])): ?>
            <div class="alert-public <?= $f['type'] === 'error' ? 'error' : 'success' ?>">
              <i class="fa-solid <?= $f['type'] === 'error' ? 'fa-circle-xmark' : 'fa-circle-check' ?> flex-shrink-0"></i>
              <?= htmlspecialchars($f['message']) ?>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>
      <?php endif; ?>

      <form action="<?= Router::url('auth/registerPost') ?>" method="POST" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="csrf_token" value="<?= $this->csrf() ?>">

        <!-- Name -->
        <div class="mb-4">
          <label class="auth-label" for="name">Full Name <span class="text-red-500">*</span></label>
          <input class="auth-input" type="text" id="name" name="name"
                 value="<?= htmlspecialchars($old['name'] ?? '') ?>"
                 placeholder="e.g. Juan dela Cruz" required minlength="3">
          <?php if (!empty($errors['name'])): ?>
            <div class="form-error"><?= htmlspecialchars($errors['name']['message']) ?></div>
          <?php endif; ?>
        </div>

        <!-- Email -->
        <div class="mb-4">
          <label class="auth-label" for="email">Email Address <span class="text-red-500">*</span></label>
          <input class="auth-input" type="email" id="email" name="email"
                 value="<?= htmlspecialchars($old['email'] ?? '') ?>"
                 placeholder="you@example.com" required>
          <?php if (!empty($errors['email'])): ?>
            <div class="form-error"><?= htmlspecialchars($errors['email']['message']) ?></div>
          <?php endif; ?>
        </div>

        <!-- Password -->
        <div class="mb-4">
          <label class="auth-label" for="password">Password <span class="text-red-500">*</span></label>
          <div class="relative">
            <input class="auth-input" type="password" id="password" name="password"
                   placeholder="Minimum 8 characters" required minlength="8"
                   style="padding-right:40px;" oninput="checkStrength(this.value)">
            <button type="button" onclick="togglePw('password','ei1')"
              class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
              <i class="fa-solid fa-eye text-sm" id="ei1"></i>
            </button>
          </div>
          <?php if (!empty($errors['password'])): ?>
            <div class="form-error"><?= htmlspecialchars($errors['password']['message']) ?></div>
          <?php endif; ?>
          <div class="mt-1.5 h-1 bg-gray-200 rounded" id="strengthBar"></div>
          <p class="text-xs text-gray-400 mt-1" id="strengthLabel"></p>
        </div>

        <!-- Confirm password -->
        <div class="mb-4">
          <label class="auth-label" for="confirm_password">Confirm Password <span class="text-red-500">*</span></label>
          <div class="relative">
            <input class="auth-input" type="password" id="confirm_password" name="confirm_password"
                   placeholder="Re-enter your password" required
                   style="padding-right:40px;" oninput="checkMatch()">
            <button type="button" onclick="togglePw('confirm_password','ei2')"
              class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
              <i class="fa-solid fa-eye text-sm" id="ei2"></i>
            </button>
          </div>
          <?php if (!empty($errors['confirm_password'])): ?>
            <div class="form-error"><?= htmlspecialchars($errors['confirm_password']['message']) ?></div>
          <?php endif; ?>
          <p class="text-xs mt-1" id="matchMsg"></p>
        </div>

        <!-- Gender Selection -->
        <div class="mb-4">
          <label class="auth-label">Gender <span class="text-red-500">*</span></label>
          <div class="grid grid-cols-2 gap-3">
            <label class="flex items-center gap-3 border border-gray-300 rounded-md p-3 cursor-pointer hover:border-brand-500 has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 transition-colors">
              <input type="radio" name="gender" value="male" required class="accent-brand-600"
                     <?= ($old['gender'] ?? '') === 'male' ? 'checked' : '' ?>>
              <div>
                <div class="text-sm font-semibold text-gray-900">Male</div>
                <div class="text-xs text-gray-400">Male tenant</div>
              </div>
            </label>
            <label class="flex items-center gap-3 border border-gray-300 rounded-md p-3 cursor-pointer hover:border-brand-500 has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 transition-colors">
              <input type="radio" name="gender" value="female" class="accent-brand-600"
                     <?= ($old['gender'] ?? '') === 'female' ? 'checked' : '' ?>>
              <div>
                <div class="text-sm font-semibold text-gray-900">Female</div>
                <div class="text-xs text-gray-400">Female tenant</div>
              </div>
            </label>
          </div>
          <?php if (!empty($errors['gender'])): ?>
            <div class="form-error"><?= htmlspecialchars($errors['gender']['message']) ?></div>
          <?php endif; ?>
        </div>

        <!-- Guardian / emergency contact -->
        <div class="mb-4 p-4 border border-amber-200 bg-amber-50 rounded-lg">
          <h2 class="text-sm font-bold text-gray-900 mb-1">
            <i class="fa-solid fa-user-shield text-amber-600"></i> Guardian / Parent / Emergency Contact
          </h2>
          <p class="text-xs text-gray-600 mb-4">
            Someone we can reach if you are in danger, and who may be notified about important account and payment updates.
          </p>

          <div class="mb-3">
            <label class="auth-label" for="guardian_name">Contact Full Name <span class="text-red-500">*</span></label>
            <input class="auth-input" type="text" id="guardian_name" name="guardian_name"
                   value="<?= htmlspecialchars($old['guardian_name'] ?? '') ?>"
                   placeholder="e.g. Maria dela Cruz (parent/guardian)" required minlength="2">
          </div>

          <div class="mb-3">
            <label class="auth-label" for="guardian_email">Contact Email <span class="text-red-500">*</span></label>
            <input class="auth-input" type="email" id="guardian_email" name="guardian_email"
                   value="<?= htmlspecialchars($old['guardian_email'] ?? '') ?>"
                   placeholder="parent@example.com" required>
          </div>

          <div>
            <label class="auth-label" for="guardian_purpose">Why should we contact this person? <span class="text-red-500">*</span></label>
            <textarea class="auth-input" id="guardian_purpose" name="guardian_purpose" rows="3" required
                      minlength="10" maxlength="500"
                      placeholder="e.g. My mother — contact in emergencies; notify her when my rent payment is confirmed."><?= htmlspecialchars($old['guardian_purpose'] ?? '') ?></textarea>
            <p class="text-xs text-gray-500 mt-1">Minimum 10 characters. This is shown to the landlord and used for payment confirmation emails.</p>
          </div>
        </div>

        <!-- Room preference -->
        <div class="mb-4">
          <label class="auth-label">Room Type Preference <span class="text-red-500">*</span></label>
          <div class="grid grid-cols-2 gap-3">
            <label class="flex items-center gap-3 border border-gray-300 rounded-md p-3 cursor-pointer hover:border-brand-500 has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 transition-colors">
              <input type="radio" name="room_type_preference" value="single" required class="accent-brand-600">
              <div>
                <div class="text-sm font-semibold text-gray-900">Single Room</div>
                <div class="text-xs text-gray-400">Private, solo occupancy</div>
              </div>
            </label>
            <label class="flex items-center gap-3 border border-gray-300 rounded-md p-3 cursor-pointer hover:border-brand-500 has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 transition-colors">
              <input type="radio" name="room_type_preference" value="shared" class="accent-brand-600">
              <div>
                <div class="text-sm font-semibold text-gray-900">Shared Room</div>
                <div class="text-xs text-gray-400">With compatible roommates</div>
              </div>
            </label>
          </div>
        </div>

        <!-- Air-conditioning preference -->
        <div class="mb-4">
          <label class="auth-label">Air-Conditioned Room Preference</label>
          <div class="grid grid-cols-2 gap-3">
            <label class="flex items-center gap-3 border border-gray-300 rounded-md p-3 cursor-pointer hover:border-brand-500 has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 transition-colors">
              <input
                type="radio"
                name="air_conditioned_preference"
                value="1"
                required
                class="accent-brand-600"
                <?= ((string)($old['air_conditioned_preference'] ?? '0')) === '1' ? 'checked' : '' ?>
              >
              <div>
                <div class="text-sm font-semibold text-gray-900">Air-conditioned</div>
                <div class="text-xs text-gray-400">Preferred comfort with A/C</div>
              </div>
            </label>
            <label class="flex items-center gap-3 border border-gray-300 rounded-md p-3 cursor-pointer hover:border-brand-500 has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 transition-colors">
              <input
                type="radio"
                name="air_conditioned_preference"
                value="0"
                class="accent-brand-600"
                <?= ((string)($old['air_conditioned_preference'] ?? '0')) === '0' ? 'checked' : '' ?>
              >
              <div>
                <div class="text-sm font-semibold text-gray-900">Not required</div>
                <div class="text-xs text-gray-400">Ok without A/C</div>
              </div>
            </label>
          </div>
        </div>

        <!-- Government ID -->
        <div class="mb-6">
          <label class="auth-label">Government ID <span class="text-red-500">*</span></label>
          <div class="border-2 border-dashed border-gray-300 rounded-md p-6 text-center hover:border-brand-500 transition-colors cursor-pointer" onclick="document.getElementById('gov_id').click()">
            <i class="fa-solid fa-cloud-arrow-up text-2xl text-gray-400 mb-2 block"></i>
            <p class="text-sm font-medium text-gray-700" id="fileLabel">Click to upload ID</p>
            <p class="text-xs text-gray-400 mt-1">JPG or PNG, max 2MB</p>
            <input type="file" id="gov_id" name="government_id" accept=".jpg,.jpeg,.png"
                   class="hidden" onchange="updateFileLabel(this)" required>
          </div>
        </div>

        <div class="bg-blue-50 border border-blue-200 rounded-md p-3 mb-6 flex gap-2 text-sm text-blue-700">
          <i class="fa-solid fa-circle-info flex-shrink-0 mt-0.5"></i>
          <span>After registering, you must complete a personality questionnaire before landlord review.</span>
        </div>

        <button type="submit" class="auth-btn">Create Account</button>
      </form>

      <p class="text-center text-sm text-gray-500 mt-5">
        Already have an account?
        <a href="<?= Router::url('auth/login') ?>" class="text-brand-600 font-semibold hover:underline">Sign in</a>
      </p>

    </div>
  </div>
</div>

<script>
function togglePw(id, iconId) {
  var inp = document.getElementById(id);
  var icon = document.getElementById(iconId);
  inp.type = inp.type === 'password' ? 'text' : 'password';
  icon.className = inp.type === 'text' ? 'fa-solid fa-eye-slash text-sm' : 'fa-solid fa-eye text-sm';
}
function checkStrength(v) {
  var bar   = document.getElementById('strengthBar');
  var label = document.getElementById('strengthLabel');
  var score = 0;
  if (v.length >= 8) score++;
  if (/[A-Z]/.test(v)) score++;
  if (/[0-9]/.test(v)) score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;
  var colors = ['','#ef4444','#f59e0b','#22c55e','#22c55e'];
  var labels = ['','Weak','Fair','Good','Strong'];
  bar.style.width = (score * 25) + '%';
  bar.style.background = colors[score] || '#e5e7eb';
  label.textContent = v.length ? labels[score] || 'Very weak' : '';
  label.style.color = colors[score] || '#6b7280';
}
function checkMatch() {
  var pw   = document.getElementById('password').value;
  var cpw  = document.getElementById('confirm_password').value;
  var msg  = document.getElementById('matchMsg');
  if (!cpw) { msg.textContent = ''; return; }
  if (pw === cpw) { msg.textContent = 'Passwords match'; msg.style.color = '#16a34a'; }
  else            { msg.textContent = 'Passwords do not match'; msg.style.color = '#dc2626'; }
}
function updateFileLabel(input) {
  var label = document.getElementById('fileLabel');
  label.textContent = input.files[0] ? input.files[0].name : 'Click to upload ID';
}
</script>